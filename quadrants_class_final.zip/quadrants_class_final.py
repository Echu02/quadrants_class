import os, random, shutil
from re import A


#Using for loop to randomly choose multiple files
def main():
    #Prompting user to enter number of files to select randomly along with directory
    source=input("Enter the Source Directory : ")

    # SETUP:
    ##############################################
    #Definition of quadrants
    # Top-Right
    smallgun_count_Q1 = 0
    biggun_count_Q1 = 0
    smallrifle_count_Q1 = 0
    bigrifle_count_Q1 = 0
    Q1fromX = 1296
    Q1fromY = 972
    Q1toX = 2592
    Q1toY = 1944
    # Top-Left
    smallgun_count_Q2 = 0
    biggun_count_Q2 = 0
    smallrifle_count_Q2 = 0
    bigrifle_count_Q2 = 0
    Q2fromX = 0
    Q2fromY = 972
    Q2toX = 1296
    Q2toY = 1944
    # Bot-Left
    smallgun_count_Q3 = 0
    biggun_count_Q3 = 0
    smallrifle_count_Q3 = 0
    bigrifle_count_Q3 = 0
    Q3fromX = 0
    Q3fromY = 0
    Q3toX = 1296
    Q3toY = 972
    # Bot-Right
    smallgun_count_Q4 = 0
    biggun_count_Q4 = 0
    smallrifle_count_Q4 = 0
    bigrifle_count_Q4 = 0
    Q4fromX = 1296
    Q4fromY = 0
    Q4toX = 2592
    Q4toY = 972
    # Middle
    ###QMfromX = 1250
    ###QMfromY = 800
    ###QMtoX = 1600
    ###QMtoY = 1100
    # Definition of min and max bounding box size | MINbb = 0 always | MAXbb means maximum to be considered small.
    gunMAXbbX = 100
    gunMINbbX = 0

    rifleMAXbbX = 100
    rifleMINbbX = 0
    ##############################################

    count_empty = 0
    count_null = 0

    class_to_check = 'gun' , 'rifle'
    files = os.listdir(source)
        
    for f in files:
        label_file = source + '/' + f.split('/')[-1]
        if os.stat(label_file).st_size != 0:
            with open(label_file) as fReader:
                for line in fReader:
                    line_split = line.split()
                    bX = int(line_split[4])
                    bY = int(line_split[5])
                    tX = int(line_split[6])
                    tY = int(line_split[7])
                    dX = tX - bX
                    dY = tY - bY
                    
                    bbox = get_bb(line)
                    if bbox['class'] == class_to_check[0]:
                        if dX > gunMINbbX and dX <= gunMAXbbX:

                            if bX >= Q1fromX and bY >= Q1fromY and tX <= Q1toX and tY <= Q1toY:
                                smallgun_count_Q1 += 1

                            elif bX >= Q2fromX and bY >= Q2fromY and tX <= Q2toX and tY <= Q2toY:
                                smallgun_count_Q2 += 1
                            
                            elif bX >= Q3fromX and bY >= Q3fromY and tX <= Q3toX and tY <= Q3toY:
                                smallgun_count_Q3 += 1
                        
                            elif bX >= Q4fromX and bY >= Q4fromY and tX <= Q4toX and tY <= Q4toY:
                                smallgun_count_Q4 += 1

                            else:
                                count_null += 1

                        elif dX > gunMAXbbX:
                            
                            if bX >= Q1fromX and bY >= Q1fromY and tX <= Q1toX and tY <= Q1toY:
                                biggun_count_Q1 += 1

                            elif bX >= Q2fromX and bY >= Q2fromY and tX <= Q2toX and tY <= Q2toY:
                                biggun_count_Q2 += 1
                            
                            elif bX >= Q3fromX and bY >= Q3fromY and tX <= Q3toX and tY <= Q3toY:
                                biggun_count_Q3 += 1
                        
                            elif bX >= Q4fromX and bY >= Q4fromY and tX <= Q4toX and tY <= Q4toY:
                                biggun_count_Q4 += 1

                            else:
                                count_null += 1

                    
                    elif bbox['class'] == class_to_check[1]:
                        if dX > rifleMINbbX and dX <= rifleMAXbbX:
                            if bX >= Q1fromX and bY >= Q1fromY and tX <= Q1toX and tY <= Q1toY:
                                smallrifle_count_Q1 += 1

                            elif bX >= Q2fromX and bY >= Q2fromY and tX <= Q2toX and tY <= Q2toY:
                                smallrifle_count_Q2 += 1
                            
                            elif bX >= Q3fromX and bY >= Q3fromY and tX <= Q3toX and tY <= Q3toY:
                                smallrifle_count_Q3 += 1
                        
                            elif bX >= Q4fromX and bY >= Q4fromY and tX <= Q4toX and tY <= Q4toY:
                                smallrifle_count_Q4 += 1

                            else:
                                count_null += 1

                        elif dX > rifleMAXbbX:           
                            if bX >= Q1fromX and bY >= Q1fromY and tX <= Q1toX and tY <= Q1toY:
                                bigrifle_count_Q1 += 1

                            elif bX >= Q2fromX and bY >= Q2fromY and tX <= Q2toX and tY <= Q2toY:
                                bigrifle_count_Q2 += 1
                            
                            elif bX >= Q3fromX and bY >= Q3fromY and tX <= Q3toX and tY <= Q3toY:
                                bigrifle_count_Q3 += 1
                        
                            elif bX >= Q4fromX and bY >= Q4fromY and tX <= Q4toX and tY <= Q4toY:
                                bigrifle_count_Q4 += 1

                            else:
                                count_null+=1
        else:
            count_empty+=1


    print("\n\n"+"$"*33+"[ Files Analyzed Successfully ]"+"$"*33)
    print("The number of small guns in quadrant 1 is {0}".format(smallgun_count_Q1))
    print("The number of small guns in quadrant 2 is {0}".format(smallgun_count_Q2))
    print("The number of small guns in quadrant 3 is {0}".format(smallgun_count_Q3))
    print("The number of small guns in quadrant 4 is {0}".format(smallgun_count_Q4))
    print('\n')
    print("The number of big guns in quadrant 1 is {0}".format(biggun_count_Q1))
    print("The number of big guns in quadrant 2 is {0}".format(biggun_count_Q2))
    print("The number of big guns in quadrant 3 is {0}".format(biggun_count_Q3))
    print("The number of big guns in quadrant 4 is {0}".format(biggun_count_Q4))
    print('\n')
    print("The number of small rifles in quadrant 1 is {0}".format(smallrifle_count_Q1))
    print("The number of small rifles in quadrant 2 is {0}".format(smallrifle_count_Q2))
    print("The number of small rifles in quadrant 3 is {0}".format(smallrifle_count_Q3))
    print("The number of small rifles in quadrant 4 is {0}".format(smallrifle_count_Q4))
    print('\n')
    print("The number of big rifles in quadrant 1 is {0}".format(bigrifle_count_Q1))
    print("The number of big rifles in quadrant 2 is {0}".format(bigrifle_count_Q2))
    print("The number of big rifles in quadrant 3 is {0}".format(bigrifle_count_Q3))
    print("The number of big rifles in quadrant 4 is {0}".format(bigrifle_count_Q4))
    print('\n')
    print("The number of empty labels is {0}".format(count_empty))
    print("The number of middle labels is {0}".format(count_null))

def get_bb(line):
            line_split = line.split()
            return {
                'class': line_split[0],
                'x1': float(line_split[4]),
                'x2': float(line_split[6]),
                'y1': float(line_split[5]),
                'y2': float(line_split[7])
}

main()